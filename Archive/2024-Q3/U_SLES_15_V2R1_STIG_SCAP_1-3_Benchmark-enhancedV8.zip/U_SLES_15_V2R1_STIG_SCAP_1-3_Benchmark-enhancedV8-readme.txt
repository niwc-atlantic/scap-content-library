This content stream was enhanced with OCIL manual questions from the STIG Manual by the NIWC SCC team.
Timestamp: 2024-08-01T10:21:32
Tool Version: 1.0
STIG Manual Version: 2.1
SCAP Benchmark Version: 2.1
Manual rules added: 95

NOTICE: Portions of the SCAP content XML file were developed at Developed at Naval Information Warfare Center Atlantic by employees of the Federal Government in the course of their official duties. Pursuant to title 17 Section 105 of the United States Code this software is not subject to copyright protection and is in the public domain. The Government assumes no responsibility whatsoever for its use by other parties, and the software is provided "AS IS" without warranty or guarantee of any kind, express or implied, including, but not limited to, the warranties of merchantability and of fitness for a particular purpose. In no event shall the Government be liable for any claim, damages or other liability, whether in an action of contract, tort or other dealings in the software. The Government has no obligation hereunder to provide maintenance, support, updates, enhancements, or modifications. We would appreciate acknowledgement if the software is used. This software can be redistributed and/or modified freely provided that any derivative works bear some notice that they are derived from it, and any modified versions bear some notice that they have been modified.

The versioning format for NIWC Enhanced content is as follows:
<DISA STIG Benchmark Version> + <Enhanced Content Version>			
DISA STIG Benchmark Version 2.1, Enhanced Content Version = 8
Enhanced SCAP Content Version: 2.1.8
Enhanced Content Filename: U_SLES_15_V2R1_STIG_SCAP_1-3_Benchmark-enhancedV8.xml
